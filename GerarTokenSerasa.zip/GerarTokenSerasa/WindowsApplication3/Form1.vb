﻿Imports System.Text
Imports Jose
Imports System.IO

Public Class Form1

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btn.Click
        'txtSenha.Text = "A1b2c5e$"
        Dim meupath As String = Path.GetTempPath
        Dim fileOUT As StreamWriter
        If txtArq.Text = "" Then
            lblMsg.Text = "Nome de arquivo é obrigatório"
            Exit Sub
        End If
        If txtSenha.Text = "" Then
            lblMsg.Text = "Campo a ser encriptado é obrigatório"
            Exit Sub
        End If
        Dim arq As String = txtArq.Text.ToLower
        txtArq.Text = arq
        Dim mt() As String = arq.Split("\")
        mt = mt(mt.Length - 1).Split(".")
        arq = mt(0)
        Dim token As String = ""
        If txtSenha.Text = "" Then txtSenha.Text = "coloque a chave aberta aqui"
        Dim secretKey As Object = Encoding.UTF8.GetBytes(arq)
        Dim payload As Object = New Dictionary(Of String, Object)() From {{"valor", txtSenha.Text}}
        token = JWT.Encode(payload, secretKey, JwsAlgorithm.HS512)
        fileOUT = My.Computer.FileSystem.OpenTextFileWriter(meupath & arq & ".dat", False) : fileOUT.Write(token) : fileOUT.Close() : fileOUT = Nothing
        TextBox1.Text = meupath & arq & ".dat"
        lblMsg.Text = ""
        lblMsg.Text &= "Foi criado o arquivo acima" & vbCrLf & vbCrLf
        lblMsg.Text &= "Copie para o diretório desejado e coloque o caminho completo" & vbCrLf
        lblMsg.Text &= "Na chave do iniprofile do WebService" & vbCrLf & vbCrLf
        lblMsg.Text &= "**** ATENÇÃO ****" & vbCrLf
        lblMsg.Text &= "O nome do arquivo não pode ser mudado" & vbCrLf
        lblMsg.Text &= "Se quiser mudar tem que gerar de novo"
        Label3.Visible = True
        TextBox1.Visible = True
        Dim real As String = JWT.Decode(token, secretKey, JwsAlgorithm.HS512)
    End Sub

    Private Sub Form1_Shown(sender As Object, e As EventArgs) Handles Me.Shown
        txtArq.Focus()
    End Sub
End Class
